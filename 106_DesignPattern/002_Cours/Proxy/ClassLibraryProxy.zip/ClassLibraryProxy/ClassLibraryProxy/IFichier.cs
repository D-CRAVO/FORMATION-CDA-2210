﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryProxy
{
	public interface IFichier
	{
		public void Lire();
		public void Ecrire();
	}
}

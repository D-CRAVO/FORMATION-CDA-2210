﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsControlLibrary;

namespace WindowsFormsApplicationEvenement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void userControlPrenom1_PrenomTrouve(object sender, PrenomEventArgs e)
        {
            UserControlPrenom monUserControl = sender as UserControlPrenom;
            if (monUserControl != null)
            {
                this.labelPrenom1.Text = "Coucou " + monUserControl.Prenom;
            }
        }

        private void userControlPrenom2_PrenomTrouve(object sender, PrenomEventArgs e)
        {
            UserControlPrenom monUserControl = sender as UserControlPrenom;
            if (monUserControl != null)
            {
                this.labelPrenom2.Text = "Coucou " + monUserControl.Prenom;
            }
        }

        private void userControlPrenom1_PrenomTrouve_1(object sender, PrenomEventArgs e)
        {
            this.labelPrenom1.Text = "Coucou " + e.Prenom;
        }

        private void userControlPrenom2_PrenomTrouve_1(object sender, PrenomEventArgs e)
        {
            this.labelPrenom2.Text = "Coucou" + e.Prenom;
        }
    }
}

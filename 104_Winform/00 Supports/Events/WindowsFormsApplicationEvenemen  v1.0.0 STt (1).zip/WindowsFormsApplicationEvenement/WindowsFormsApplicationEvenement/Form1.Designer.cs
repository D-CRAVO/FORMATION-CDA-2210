﻿namespace WindowsFormsApplicationEvenement
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControlPrenom2 = new WindowsFormsControlLibrary.UserControlPrenom();
            this.userControlPrenom1 = new WindowsFormsControlLibrary.UserControlPrenom();
            this.labelPrenom1 = new System.Windows.Forms.Label();
            this.labelPrenom2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // userControlPrenom2
            // 
            this.userControlPrenom2.Location = new System.Drawing.Point(76, 160);
            this.userControlPrenom2.Name = "userControlPrenom2";
            this.userControlPrenom2.Prenom = "Marjo";
            this.userControlPrenom2.Size = new System.Drawing.Size(214, 100);
            this.userControlPrenom2.TabIndex = 1;
            this.userControlPrenom2.PrenomTrouve += new System.EventHandler<WindowsFormsControlLibrary.PrenomEventArgs>(this.userControlPrenom2_PrenomTrouve_1);
            // 
            // userControlPrenom1
            // 
            this.userControlPrenom1.Location = new System.Drawing.Point(76, 44);
            this.userControlPrenom1.Name = "userControlPrenom1";
            this.userControlPrenom1.Prenom = "Theo";
            this.userControlPrenom1.Size = new System.Drawing.Size(214, 100);
            this.userControlPrenom1.TabIndex = 0;
            this.userControlPrenom1.PrenomTrouve += new System.EventHandler<WindowsFormsControlLibrary.PrenomEventArgs>(this.userControlPrenom1_PrenomTrouve_1);
            // 
            // labelPrenom1
            // 
            this.labelPrenom1.AutoSize = true;
            this.labelPrenom1.Location = new System.Drawing.Point(275, 82);
            this.labelPrenom1.Name = "labelPrenom1";
            this.labelPrenom1.Size = new System.Drawing.Size(0, 17);
            this.labelPrenom1.TabIndex = 2;
            // 
            // labelPrenom2
            // 
            this.labelPrenom2.AutoSize = true;
            this.labelPrenom2.Location = new System.Drawing.Point(278, 198);
            this.labelPrenom2.Name = "labelPrenom2";
            this.labelPrenom2.Size = new System.Drawing.Size(0, 17);
            this.labelPrenom2.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 398);
            this.Controls.Add(this.labelPrenom2);
            this.Controls.Add(this.labelPrenom1);
            this.Controls.Add(this.userControlPrenom2);
            this.Controls.Add(this.userControlPrenom1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.Form1_Click);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private WindowsFormsControlLibrary.UserControlPrenom userControlPrenom1;
        private WindowsFormsControlLibrary.UserControlPrenom userControlPrenom2;
        private System.Windows.Forms.Label labelPrenom1;
        private System.Windows.Forms.Label labelPrenom2;
    }
}


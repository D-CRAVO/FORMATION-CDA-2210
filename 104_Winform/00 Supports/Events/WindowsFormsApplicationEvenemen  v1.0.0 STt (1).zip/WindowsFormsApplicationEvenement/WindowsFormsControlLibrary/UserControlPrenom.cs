﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsControlLibrary
{
    public partial class UserControlPrenom : UserControl
    {
        public event EventHandler<PrenomEventArgs> PrenomTrouve;

        private string prenom;

        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }


        public UserControlPrenom()
        {
            InitializeComponent();
        }

        private void textBoxPrenom_TextChanged(object sender, EventArgs e)
        {
            if (this.textBoxPrenom.Text.Equals(prenom))
            {
                this.textBoxPrenom.BackColor = Color.Red;
                if (PrenomTrouve != null)
                {
                    PrenomTrouve(this, new PrenomEventArgs(prenom));
                }
            }
        }
    }
}

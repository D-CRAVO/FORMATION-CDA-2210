﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsControlLibrary
{
    public class PrenomEventArgs:EventArgs
    {
        string prenom;

        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        public PrenomEventArgs(string _prenom)
        {
            prenom = _prenom;
        }
    }
}

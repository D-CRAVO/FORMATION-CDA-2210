using Microsoft.EntityFrameworkCore;
using System.ComponentModel;

namespace EFWinforms
{
    public partial class Form1 : Form
    {

        private ProductsContext? dbContext;
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Au chargement de la form, r�cuperation du DbContext souhait�, si la base n'existe pas 
        /// , la cr�er et insert les donn�es puis les chargent, sinon charge directement les donn�es.
        /// Attache la DataSource en recup�rant les donn�es du dbContext
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.dbContext = new ProductsContext();

            // pour supprimer la DB si elle existe
            // this.dbContext.Database.EnsureDeleted();
            this.dbContext.Database.EnsureCreated();
            this.dbContext.Categories.Load();

            this.categoryBindingSource.DataSource = dbContext.Categories.Local.ToBindingList();
        }
        /// <summary>
        /// S'assure de fermer la connexion avant de fermer l'application
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            this.dbContext?.Dispose();
            this.dbContext = null;
        }

        /// <summary>
        /// charge la liste de produits correspondant � la categorie choisie, est attach� � l'�venement SelectionChanged du DataGridView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridViewCategories_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dbContext != null)
            {
                // stock la category selectionn�e
                var category = (Category)this.dataGridViewCategories.CurrentRow.DataBoundItem;

                if (category != null)
                {
                    // r�cup�re les products li�s � la cat�gorie s�l�ctionn�e
                    this.dbContext.Entry(category).Collection(e => e.Products).Load();
                }
            }
        }
        /// <summary>
        /// Enregistre les changements apport�s dans la base de donn�es sur l'event CLick du boutton et rafraichit l'affichage
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            // repercute les changements du dbSet a la BDD
            this.dbContext!.SaveChanges();
            // rafraichit les deux datagridViews avec les changements
            this.dataGridViewCategories.Refresh();
            this.dataGridViewProducts.Refresh();
        }
    }
}
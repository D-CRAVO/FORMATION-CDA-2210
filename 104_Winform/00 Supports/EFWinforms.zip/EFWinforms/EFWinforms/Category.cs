﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFWinforms
{
    public class Category
    {   
        /// <summary>
        /// Représente l'id de la table category, le Key est une data Annotation permettant de spécifier des contraintes et d'ajouter des contrôles sur les éléments
        /// </summary>
        [Key]
        public int CategoryId { get; set; }
        [Required,MaxLength(30)]
        public string? Name { get; set; }
        /// <summary>
        /// Liste des objets Products correspondant à la catégorie
        /// </summary>
        public virtual ObservableCollectionListSource<Product> Products { get; } = new();
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFWinforms
{
    public class Product
    {
        /// <summary>
        /// la data annnotation [KEY] est facultative dans ce cas car le framework va scanner le nom de la proprieté et
        /// si il y a "Id" à l'interieur l'identifier comme tel, dans le cas ou plusieurs propriétés contiennent "Id" il va alors chercher 
        /// le quel contient le nom de la classe + "Id"
        /// </summary>
        [Key]
        public int ProductId { get; set; }
        [Required]
        public string? Name { get; set; }

        /// <summary>
        /// Le champ qui deviendra la clef étrangère vers Category (non obligatoire pour le fonctionnement EF qui fera le lien sans)
        /// </summary>
        [ForeignKey("Category")]
        public int CategoryId { get; set; }

        /// <summary>
        /// Correspond à la Category correspondant au produit 
        /// </summary>
        public virtual Category Category { get; set; } = null!;
    }
}

﻿namespace OC.Exercice
{
    public enum Resultat
    {
        Gagne,
        Perdu
    }
}
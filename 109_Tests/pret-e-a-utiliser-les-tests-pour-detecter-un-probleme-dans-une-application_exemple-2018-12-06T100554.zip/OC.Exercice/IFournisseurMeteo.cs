﻿namespace OC.Exercice
{
    public interface IFournisseurMeteo
    {
        Meteo QuelTempsFaitIl();
    }
}
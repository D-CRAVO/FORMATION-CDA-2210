﻿namespace OC.Exercice
{
    public interface IMonstre
    {
        bool EstVivant();
        void PerdsUnCombat(int nb);
    }
}
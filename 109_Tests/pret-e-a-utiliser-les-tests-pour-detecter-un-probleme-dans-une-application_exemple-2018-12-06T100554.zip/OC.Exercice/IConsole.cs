﻿namespace OC.Exercice
{
    public interface IConsole
    {
        void Ecrire(string message);
        void EcrireLigne(string message);
    }
}
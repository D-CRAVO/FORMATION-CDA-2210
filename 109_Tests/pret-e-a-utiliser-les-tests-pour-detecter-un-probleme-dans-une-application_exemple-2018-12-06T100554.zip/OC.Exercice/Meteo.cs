﻿namespace OC.Exercice
{
    public enum Meteo
    {
        Soleil,
        Pluie,
        Tempete
    }
}
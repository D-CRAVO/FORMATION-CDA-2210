﻿namespace OC.Exercice
{
    public interface ILanceurDeDe
    {
        int Lance();
    }
}
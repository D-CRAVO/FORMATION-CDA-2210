﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLSpa
{
    public enum EnumRace
    {
        Abyssin = 1,
        Europeen = 2,
        MaineCoon = 3,
        Sphynx = 4
    }
}

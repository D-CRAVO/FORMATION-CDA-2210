//on récupère les éléments pour l'accordéon
const toggleButton = document.getElementById('toggle-description');
const descriptionDiv = document.getElementById('image-description');


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crypto;

/**
 *
 * @author regis
 */
public class Tools {

    public static char toHexa (int b)
    {
        char result='0' ;
        if ( (b >=0 ) && (b <= 9))
            result = (char) ('0' + b);
        else if ( (b >= 10) && (b <= 15) ) 
             result = (char) ('A' + b - 10 ) ;
        return result;
    }
    public static String toStringHex(byte[] tab) 
    {
        StringBuffer buf = new StringBuffer();
        for (int j = 0; j < tab.length; j++) 
        {            
            buf.append( toHexa( tab[j] / 16) ) ;
            buf.append( toHexa(tab[j] % 16) );
        }
        return buf.toString();
    }
    
}

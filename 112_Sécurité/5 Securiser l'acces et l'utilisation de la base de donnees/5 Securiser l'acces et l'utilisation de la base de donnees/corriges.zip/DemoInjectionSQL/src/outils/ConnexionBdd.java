/*
Régis Lécu
25/08/2016
Classe de connexion de base de données pour démonstration d'injection SQL
*/
package outils;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConnexionBdd {

    private static ConnexionBdd _instance = null;

    public static ConnexionBdd getInstance() {
        if (_instance == null) {
            _instance = new ConnexionBdd();
        }
        return _instance;
    }

    public Connection ouvrir() 
    {
        Connection co = null;
        try 
        {
            // pour la démonstration, utilisation de la base derby
            // à laquelle on a ajouté la table Utilisateur
            // TODO : initialisez ici votre connexion vers SQL Server ou Oracle 
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String url = "jdbc:derby://localhost:1527/sample";          

            co = DriverManager.getConnection(url, "app", "app");
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        return co;
    }

}

-- cr�ation de la base de d�mos
-- L�cu R�gis, 12/07/2016
create database demoInjection
go
use demoInjection
go
-- cr�ation de la table utilisateur
CREATE TABLE utilisateur
(
	name varchar(30) primary key,
	mdp varchar(20) NULL
)
go

-- cr�ation de la proc�dure stock�e (avec exception)
CREATE PROCEDURE userExist @name varchar(30), @mdp varchar(20) 
AS
BEGIN
 declare @nb int;
 declare @succes bit=0;
 
 -- TODO : valider le nom et le mdp (r�gles de gestion ?) 
  begin try
   select @nb = count (*)
   from utilisateur
   where name = @name and mdp = @mdp;	
 
   if @nb = 1 
     set @succes=1;
 
  end try
  begin catch
     print error_message(); -- en cours mise au point seulement 
     set @succes = -1 -- indique une erreur syst�me sans pr�cision
  end catch
   
END
go

-- programme de test (TRAME, � compl�ter par un jeu d'essai fonctionnel complet
-- et un jeu d'essai "malveillant"
declare @ret int
exec @ret =  userExist 'toto', 'mdp1'
print @ret


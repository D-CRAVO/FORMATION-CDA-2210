package demonumericexception;

import tools.Lire;

public class DemoNumericException 
{
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("***** L'integer overflow en langage Java *****************");
     
        System.out.println("Nombre entre " + Short.MIN_VALUE + " et " + Short.MAX_VALUE + ":");
              
        // 1) démonstration d'un integer overflow  en Java
        // Dans les bibliothèques de conversion, tout va bien
        // essayer des nombres inférieurs et supérieurs à 32767 et observer l'exception NumberFormatException
        short nombre =0;
        try
        {
            String s = Lire.Chaine();
            nombre = Short.valueOf(s);
            System.out.println("Votre nombre vaut : " + nombre);           
        }
        catch (NumberFormatException e) 
        {
            System.out.println(e);          
        }
        
        // 2) Dans les calculs arithmétiques, aucun overflow n'est teste !
        // c'est au développeur de prévoir les overflow
        short result = nombre;
        // result = result + 10000;
        result += 10000;
        System.out.println(nombre + " + 10000 = " + result);           
        
        // 3) Tentative d'attaque exploitant l'integer overflow
	char tab[] = new char[40000];
	int j ;
        for (j = 0; j < 10000 ; j++)
            tab[j] = 'P';			// avant 10000, case "privilégiée" marquée par un P
	for (j = 10000; j < tab.length; j++)
            tab[j] = 'U';		        // après 10000, case "utilisateur lamda" marquée par un U

        // on ne consulte que la zone utilisateur : on démarrre l'affichage à 10000
        // on n'affiche que l'indice pour la démonstration
        // On constate que l'overflow se produit : 32767 -> -32768
        // Si l'on décommente la ligne suivant, on sort donc sur l'exception 
        // Array Out of Bounds Exception
        
        short i = result;  // on parcourt la zone utilisateur (à partir de 10000)
        while ( i < tab.length)
        {       
          System.out.println( "Indice de consultation: " + i );
          // System.out.println( "valeur case = " + tab[i] );
          i++;
        }    
    }
  
}

/* Programme Java : détection d'une tentative de buffer overflow en Java
et gestion de l'exception
Lécu Régis, 03/06/2016
Points à noter : 
- la tentative de buffer overflow est détectée par le code généré automatiquement par java
et provoque une exception, AVANT LE DEBORDEMENT
- en Java, les tableaux sont dynamiques et alloués dans le TAS, comme les objets
*/
package demodebordement;
public class DemoDebordement {
    public static void main(String[] args) {
        String prenom = "regis";
        char tabbug[] = new char[8];
       
        System.out.println("*** L'exception Array Index Out of Bounds en Java ************\n");

        try 
        {
            System.out.println("Au départ, PRENOM contient " + prenom);
            for (int i = 0; i <= 8; i++) 
            {
                tabbug[i] = '#';
            }
        }
        catch (Exception e) 
        {
            System.out.println("Exception :"  + e);
        }
        System.out.println("Après l'exception, PRENOM contient toujours : " + prenom);

    }

}

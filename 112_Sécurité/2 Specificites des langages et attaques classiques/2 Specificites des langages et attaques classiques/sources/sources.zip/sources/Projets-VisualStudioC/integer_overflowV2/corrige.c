/* Version corrig�e, sans overflow :
puisque la taille du tableau est impos�e par le cahier des charges, on change le type de l'indice en int
*/
int main()
{
	printf("\n\n********** Sans integer overflow  *************************\n\n");	
	#define MAX		70000					// nombre total de cases du tableau (INCOHERENT avec le type de l'indice !)
	#define NBPRIV	30000					// nombre de cases r�serv�es � un utilisateur privil�gi� en d�but de tableau

	char tab[MAX];
	int i;
	for (i = 0; i < NBPRIV; i++)
		tab[i] = 'P';					// case "privil�gi�e" marqu�e par un P
	for (i = NBPRIV; i < MAX; i++)
		tab[i] = 'U';					// case "utilisateur lamda" marqu�e par un U

	printf("Votre indice entre 0 et %d ?", MAX - NBPRIV - 1);
	unsigned int nombre;
	scanf("%d", &nombre);
	if (nombre >= MAX - NBPRIV)
		printf("Indice errone:%d\n", nombre);
	else
	{
		// rentrez un nombre � partir de 35536 pour provoquer l'overflow
		unsigned int i = NBPRIV + nombre;
		printf("L'utilisateur de base consulte la donnee numero : %d\n", i);
		printf("La donnee demandee est: %c\n", tab[i]);
	}
}
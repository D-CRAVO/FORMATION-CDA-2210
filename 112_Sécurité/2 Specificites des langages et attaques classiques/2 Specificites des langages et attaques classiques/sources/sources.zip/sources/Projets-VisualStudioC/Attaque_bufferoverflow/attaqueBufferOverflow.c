/* Programme C de d�monstration de l'attaque par "buffer overflow" (2) :
L�cu R�gis, 06/06/2016

Points � noter :
Dans cette d�monstration, on "exploite" l'une des vuln�rabilit�s vues pr�c�demment pour se "loguer"
de fa�on inconditionnelle
*/
#include <stdio.h>

// variables "statiques" : ont une adresse fixe, une dur�e de vie pendant tout le programme,
//   et elles sont dans l'ordre de leur d�claration en m�moire
static char tampon[10];
static int ok;

// fonction vuln�rable (mauvaise utilsiation du scanf sans limite de taille de saisie)
void verifie_mot_de_passeBad() {
	// scanf non prot�g� : on peut �craser le tableau qui suit 
	ok = 0;
	printf("Votre mot de passe:");
	scanf("%s", tampon);
	if (strcmp(tampon, "secret") == 0)
	   	ok = 1;	
}


// fonction corrig�e : avec limitation de taille dans le scanf
void verifie_mot_de_passeGood() {
	// scanf non prot�g� : on peut �craser le tableau qui suit 
	ok = 0;
	printf("Votre mot de passe:");
	scanf("%9s", tampon);					// limitation � 9 de la taille de saisie
	if (strcmp(tampon, "secret") == 0)
		ok = 1;
}

void main()
{	
	printf("\n\n********** L'attaque par Buffer Overflow en langage C ***\n\n");
	
	printf("TAMPON est a l'adresse:%p\n", tampon);
	printf("OK est a l'adresse:%p\n", &ok);

	verifie_mot_de_passeBad();
	if (ok)
	{
		printf("=> Vous etes peut-etre connecte en administrateur (ou un mechant garcon!) \n");
	}
	else
	{
		printf("xxxx Utilisateur inconnu\n");
	}

	verifie_mot_de_passeGood();
	if (ok)
	{
		printf("=> Cette fois, vous etes VRAIMENT connecte en administrateur \n");
	}
	else
	{
		printf("xxxx Utilisateur inconnu\n");
	}
	
	

}
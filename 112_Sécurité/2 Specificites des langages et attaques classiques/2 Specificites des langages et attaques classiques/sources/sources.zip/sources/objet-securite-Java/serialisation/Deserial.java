
package deserialisation;

import java.io.*;

        
public class Deserial 
{
    public static void main(String[] args)
            throws FileNotFoundException, IOException,
            ClassNotFoundException
    {
        FileInputStream fis = new FileInputStream("friend");
        ObjectInputStream ois = new ObjectInputStream(fis);
        Friend f = (Friend) ois.readObject();
        
        System.out.println("Je récupère bien : " + f.getSomething() );
    }
}

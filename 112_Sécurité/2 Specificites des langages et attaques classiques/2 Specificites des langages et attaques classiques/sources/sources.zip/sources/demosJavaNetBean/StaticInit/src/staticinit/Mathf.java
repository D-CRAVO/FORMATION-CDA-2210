/*
  Maîtriser son code Java
  Cette classe Mathf, possède un bloc d'initialisation statique
qui est appelé au premier chargement de la classe (et exporte
pour la démo une valeur de pi incorrecte)
*/
package staticinit;

/**
 *
 * @author regis
 */
public class Mathf {
    public static double pi;
   
    // bloc d'initialisation statique de la classe Mathf
    static
    {
        System.out.println("Bloc d'initialisation de Mathf)");
        pi = Math.PI + 0.2;
        System.out.println("Ici, je fais ce que je veux (sans rapport avec pi");
    }
}

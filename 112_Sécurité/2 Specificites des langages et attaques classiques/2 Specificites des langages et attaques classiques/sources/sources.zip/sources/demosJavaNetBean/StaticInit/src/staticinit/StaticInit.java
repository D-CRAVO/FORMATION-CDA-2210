/*
 Maîtriser son code :
Consulter une variable statique dans une bibliothèque (Mathf)
exécuter les blocs d'initialisation de cette bibliothèque
(d'où possibilité d'attaque si la bibliothèque n'est pas sure)
 */
package staticinit;
public class StaticInit
{
    public static void main(String[] args) {
        if (Mathf.pi - 3.1415 < 0.0001) {
            System.out.println("Hello world : pi=" + Mathf.pi);
        } else {
            System.out.println("Hello strange universe : pi=" + Mathf.pi );
        }
    }

}

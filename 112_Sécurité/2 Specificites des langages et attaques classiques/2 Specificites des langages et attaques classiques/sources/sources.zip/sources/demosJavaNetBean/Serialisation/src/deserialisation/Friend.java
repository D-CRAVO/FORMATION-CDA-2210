package deserialisation;

import java.io.Serializable;

public class Friend implements Serializable
{
    private String s = null;
    static
    {
          System.out.println("et là, je suis méchant !");
    }
    public Friend()
    {
        s = "something";
      
        
    }
    public String getSomething ()
    {
        return s;
    }
}

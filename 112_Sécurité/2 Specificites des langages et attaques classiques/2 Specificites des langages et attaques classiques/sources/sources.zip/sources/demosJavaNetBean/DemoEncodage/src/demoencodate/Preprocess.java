package demoencodate;
/* Les dangers du Preprocesseur et de l'encodage UTF8
Lécu Régis, 14/06/2016 (repris d'un exemple ANSII)

Un encodage tel que Utf-8 est très délicat à traiter, et justifierait de nombreuses
remarques de sécurité :
- En standard, le compilateur Java accepte cet encodage pour le source
- les codes UTF8 sont PREPROCESSES, AVANT la compilation, ce qui IGNORE les commentaires
- le caractère UNICODE u00a est un LINE FEED qui va à la ligne suivante et sort du commentaire //
- le caractère UNICODE u007d est une accolade fermante } qui termine donc le bloc du if
- le caractère UNICODE u007b est une accolade ouvrant { 
=> l'affichage se donc fait de façon inconditionnelle
*/
public class Preprocess 
{    public static void ma\u0069n(String[] args) 
    {
        if (false == true) 
        { // \u000a\u007d\u007b
            System.out.println("Bad things happen!");
        }
    }
}
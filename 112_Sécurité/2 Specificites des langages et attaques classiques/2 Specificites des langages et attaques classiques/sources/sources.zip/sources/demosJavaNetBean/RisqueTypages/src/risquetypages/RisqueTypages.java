package risquetypages;

public class RisqueTypages 
{
    private static void safewrite(int tab[], int size, char ind, int val) 
    {
        System.out.println("safewrite => i vaut : " + (int) ind);
        if (ind < size)
        {
            tab[ind] = val;
             System.out.println("==>Ecriture réussie \n");
        }
        else 
        {
            System.out.println("==> Hors limite  \n" );
        }
    }
    public static void main(String[] args) 
    {
        final int  MAX= 120;
	int tab[] = new int [MAX];
	System.out.println("ecriture a l'indice 65534");
        safewrite (tab, MAX,  65534, 1);
        System.out.println("ecriture a l'indice 65538\n");
        safewrite(tab, MAX, (char) 65538, 1);      
    }

}


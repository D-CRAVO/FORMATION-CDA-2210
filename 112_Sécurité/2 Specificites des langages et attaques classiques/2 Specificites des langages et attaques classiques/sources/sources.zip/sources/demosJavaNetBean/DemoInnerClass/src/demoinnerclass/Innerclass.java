package demoinnerclass;
/* Traits du source non préservés dans le Byte Code : les classes internes
Lécu Régis, 14/06/2016 (repris d'un exemple ANSII)

Java permet de définir des classes internes, mais elles ne
ne sont pas supportées en bytecode ! 
Le compilateur remet tout à plat…et retire les private 
- la méthode static print de la classe Innerinner affiche l'attribut privé a de la 
classe principale Innerclass
- inversement, le main, défini dans la classe principale, affiche l'attribut privé b de la
classe interne Innerinner
*/
public class Innerclass {

    private static int a = 42;

    static public class Innerinner {

        private static int b = 54;

        public static void print() 
        {
            System.out.println(Innerclass.a);
        }
    }

    public static void main(String[] args) 
    {        
        System.out.println(Innerinner.b);
        Innerinner.print();
    }
}
 

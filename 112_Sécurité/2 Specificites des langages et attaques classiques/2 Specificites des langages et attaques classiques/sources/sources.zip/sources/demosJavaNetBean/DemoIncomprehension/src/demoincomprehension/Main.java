/* Les dangers d'une mauvaise compréhension du langage !
Cet exemple ANSSI est repris d'un forum
http://thedailywtf.com/articles/comments/Java-Destruction
où cet extrait de code erroneé faisait l'objet d'un appel à commentaires
Les réponses sont EFFRAYANTES !
*/
package demoincomprehension;

/**
 *
 * @author regis
 */
public class Main {

    public static void main (String[] args) {
        int tab[] = new int[10];
        for (int i = 0; i < tab.length; i++) {
            tab[i] = i;
        }

        Destruction.delete(tab);
        
        for (int i = 0; i < tab.length; i++) {
            System.out.print(tab[i] + " ");
        }
    }
}


package demoincomprehension;

public class Destruction 
{
    public static void delete (Object object)
    {
        object = null;
    }
}

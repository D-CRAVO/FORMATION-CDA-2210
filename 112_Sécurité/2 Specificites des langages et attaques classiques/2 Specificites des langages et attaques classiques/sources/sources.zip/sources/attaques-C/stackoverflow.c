/* Corruption de la Pile Syst�me suite � un Buffer Overflow
(Exemple fourni par l'ANSSI)
avec d�tournement vers une fonction pr�existante (sans injection de code)

Ce programme provoque un Stack Overflow qui �crase l'adresse de retour dans la fonction SET
en lui substituant l'adresse de la fonction BAD.
Il s'agit ici d'un BUG (qui cr�e une vuln�rabilit� et pourrait �tre exploit� dans une attaque)

Compilez ce programme en mode release et en mode debug. Obervez les diff�rences
Faire le tourner sans et sous debugger
*/
#include <stdio.h>
#include <stdlib.h>

/* A l'appel de la fonction SET, le main empile les param�tres dans l'ordre inverse : d'abord v, puis s
 puis il empile l'adresse de retour (adresse du printf ("hello word") dans le main)
 Cette fonction bugu�e �crase l'adresse de retour, en la rempla�ant par l'adresse de la fonction BAD.

 D�taillons :
-   &s pointe sur le param�tre s dans la Pile, donc l'adresse imm�diatement apr�s l'adresse de retour
-   le param�tre s vaut 1 (dans le cas du bug) donc &s-s vaut &s-1
-   &s-1 pointe donc sur l'adresse de retour (attention : -1 d�cr�mente l'adresse de 4 octets car c'est un pointeur d'int)
-   le param�tre v de type int contient en r�alit� l'adresse de la fonction BAD 
(gr�ce au CAST dans l'appel de la fonction set dans le main : set (1, (int) bad);
*/
void set(int s, int v)
{ 	
	*(&s - s) = v; 
}

void bad()
{ 
	printf("Bad things happen!\n");
	exit(0);
}

int main(void)
{
	set(1, (int)bad); 
	printf("Hello world\n"); 
	return 0;
}

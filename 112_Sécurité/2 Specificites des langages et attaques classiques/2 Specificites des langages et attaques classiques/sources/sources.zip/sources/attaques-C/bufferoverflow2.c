/* Typage faible et  Buffer Overflow
(Exemple fourni par l'ANSSI)

Une erreur de type (transtypage par exemple) 
peut donner lieu � un dysfonctionnement comme le buffer overflow, voire une vuln�rabilit� silencieuse 
(sans aucune remont�e d�alerte, ni � la compilation ni � l�ex�cution). 
Par exemple la fonction C SAFEWRITE a pour but de r�aliser une �criture d�une valeur
val dans le tableau tab de taille size, � l�indice ind, en v�rifiant au pr�alable que l�indice
appartient aux bornes du tableau.

Malheureusement, un appel comme safewrite(tab,120,128,1) ne va pas g�n�rer de message
d�erreur, bien que 128 soit plus grand que la taille 120. Cette erreur inattendue s�explique par la
conversion implicite qui est r�alis�e lors de l�appel de la fonction, afin de transtyper 128 vers un
signed char.
*/
void safewrite(int tab[], int size, signed char ind, int val) 
{
	if (ind<size) 
		tab[ind] = val;
	else 
		printf("==> Hors limite !\n");
}

int main(void) 
{
	#define MAX 120
	int tab[MAX];
	printf("ecriture a l'indice 127");
	safewrite(tab, MAX, 127, 1);
	printf("ecriture a l'indice 128\n");
	safewrite(tab, MAX, 128, 1);
	return 0;
}
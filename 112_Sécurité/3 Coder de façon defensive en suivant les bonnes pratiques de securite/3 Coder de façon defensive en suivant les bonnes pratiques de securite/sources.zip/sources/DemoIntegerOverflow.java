/* 
    Démonstration de l'integer overflow en Java
    L'indice i provoque un overflow
    entrainant une boucle infinie
*/
package demonumericexception;
public class DemoIntegerOverflow
{
    public static void main(String[] args)
    {
        System.out.println("* démonstration de l'integer overflow en Java ***");
        int i = 1;  
        try 
        {
            while (i < Integer.MAX_VALUE - 1000)
            {               
               // TODO : sécuriser le calcul pour éviter l'overflow
               i = i + 100000;
               System.out.println("i = " + i);   
            }
        } 
        catch (Exception e) 
        {
        
            System.out.println("i = " + i);   
            System.out.println(e);
        }   
    }
}
        
   



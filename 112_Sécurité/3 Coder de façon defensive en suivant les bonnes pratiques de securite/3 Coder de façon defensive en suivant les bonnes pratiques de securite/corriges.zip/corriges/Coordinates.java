package demoinnerclass;

public class Coordinates 
{
    private int x=30;
    private int y=20;

    public class Point 
    {
        public void getPoint() {
            System.out.println("(" + x + "," + y + ")");
        }
    }
    
    private class PointV2 
    {
        private void getPoint() {
            System.out.println("(" + x + "," + y + ")");
        }
    }
}

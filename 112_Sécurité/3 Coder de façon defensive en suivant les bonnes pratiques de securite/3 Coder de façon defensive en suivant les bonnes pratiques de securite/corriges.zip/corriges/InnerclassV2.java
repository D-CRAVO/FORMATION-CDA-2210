package demoinnerclass;
/* Traits du source non préservés dans le Byte Code : les classes internes
Lécu Régis, 22/06/2016 
Version 2 avec préconisation du CERT
 */
public class InnerclassV2 {

    private static int a = 42;

    static private class Innerinner {

        private static int b = 54;

        private static void print() {
            System.out.println(InnerclassV2.a);
        }
    }

    public static void main(String[] args) 
    {
        // On lance le Security Manager (ne change rien sur ce problème !)
        System.setSecurityManager(new SecurityManager());
        
        // Sur les classes statiques, les attributs private ne résolvent RIEN
        System.out.println(Innerinner.b);
        Innerinner.print();

        // reprise de la fiche du CERT avec une classe imbriquée non statique
        Coordinates c = new Coordinates();
        Coordinates.Point p = c.new Point ();        
        p.getPoint() ;
        
        // Coordinates.PointV2 p = c.new PointV2();  // NE COMPILE PAS : privé
    }
}
